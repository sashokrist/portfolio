/* Array of objects */
var questions = [{
    "question": "C# is ?",
    "option1": "OOP language",
    "option2": "Client/Server language",
    "answer": "1"
},
    {
    "question": "Java is ?",
        "option1": "OOP language",
        "option2": "A Script language",
        "answer": "1"
},
    {
    "question": "PHP is?",
        "option1": "OOP language",
        "option2": "Client/Server language",
        "answer": "2"
}];